package com.cg.mywalletapp.service;

import java.math.BigDecimal;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

import com.cg.mywalletapp.beans.Customer;
import com.cg.mywalletapp.beans.Wallet;
import com.cg.mywalletapp.exception.IMyException;
import com.cg.mywalletapp.exception.InsufficientBalanceException;
import com.cg.mywalletapp.exception.InvalidInputException;
import com.cg.mywalletapp.repo.WalletRepo;
import com.cg.mywalletapp.repo.WalletRepoImpl;

public class WalletServiceImpl implements WalletService {
	WalletRepo repo = null;

	public WalletServiceImpl() {
		repo = new WalletRepoImpl();
	}

	public void createAccount(Customer customer) {
		repo.save(customer);

	}

	public Customer showBalance(String mobileNo) {
		Customer customer = repo.findOne(mobileNo);
		return customer;
	}

	public Customer fundTransfer(String sourceMobileNo, String targetMobileNo, BigDecimal amount) {
		Customer senderFund = repo.findOne(sourceMobileNo);
		BigDecimal senderBalance = senderFund.getWallet().subtract(amount);
		senderFund.setWallet(senderBalance);
		repo.updateWallet(sourceMobileNo, senderBalance);
		Customer receiverFund = repo.findOne(targetMobileNo);
		BigDecimal receiverBalance = receiverFund.getWallet().add(amount);
		receiverFund.setWallet(receiverBalance);
		repo.updateWallet(targetMobileNo, receiverBalance);
		repo.addTransactions(sourceMobileNo,
				"From Account : " + sourceMobileNo + "To Account : " + targetMobileNo + " Amount : " + amount);
		repo.addTransactions(targetMobileNo,
				"From Account : " + sourceMobileNo + "To Account : " + targetMobileNo + " Amount : " + amount);
		return receiverFund;

	}

	public Customer depositAmount(String mobileNo, BigDecimal amount) {

		Customer customer = repo.findOne(mobileNo);
		BigDecimal depositeAmount = customer.getWallet().add(amount);
		customer.setWallet(depositeAmount);
		repo.addTransactions(mobileNo, "Amount Deposit :" + amount + " Balance : " + depositeAmount);
		repo.updateWallet(mobileNo, depositeAmount);
		return customer;

	}

	public Customer withdrawAmount(String mobileNo, BigDecimal amount) {

		Customer customer1 = repo.findOne(mobileNo);
		BigDecimal withdrawAmount = customer1.getWallet().subtract(amount);
		customer1.setWallet(withdrawAmount);
		repo.addTransactions(mobileNo, "Amount Withdraw : " + amount + "  Balance : " + withdrawAmount);
		repo.updateWallet(mobileNo, withdrawAmount);
		return customer1;

	}

	public List<String> printTransactions(String mobileNo) {
		return repo.printTransaction(mobileNo);
	}

	public boolean validateCreateMethod(String name, String mobileNo) throws InvalidInputException {
		boolean result = false;
		if (name.trim().matches("^[A-Z a-z]*")) {
			if (mobileNo.matches("\\d{10}")) {
				result = true;
			} else {
				throw new InvalidInputException(IMyException.ERROR2);

			}

		} else {
			throw new InvalidInputException(IMyException.ERROR1);

		}
		return result;
	}

	public boolean validateBalance(BigDecimal balance, String mobileNo) throws InsufficientBalanceException {
		boolean result = false;
		BigDecimal amt = repo.findOne(mobileNo).getWallet();

		if (balance.compareTo(amt) == -1) {
			result = true;

		} else {
			throw new InsufficientBalanceException(IMyException.ERROR3);
		}
		return result;
	}

	public boolean validateFundTransfer(BigDecimal balance, String mobileNo) throws InsufficientBalanceException {
		boolean result = false;
		BigDecimal amt = repo.findOne(mobileNo).getWallet();

		if (balance.compareTo(amt) == -1) {
			result = true;

		} else {
			throw new InsufficientBalanceException(IMyException.ERROR4);
		}

		return result;

	}

	public boolean checkMobileAvailable(String monbile) throws InvalidInputException {
		
		return repo.checkMobileAvailable(monbile);
	}


	



	

}
