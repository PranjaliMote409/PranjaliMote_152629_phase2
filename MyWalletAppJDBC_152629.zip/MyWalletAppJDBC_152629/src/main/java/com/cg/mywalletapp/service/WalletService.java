package com.cg.mywalletapp.service;

import java.math.BigDecimal;
import java.util.List;

import com.cg.mywalletapp.beans.Customer;
import com.cg.mywalletapp.exception.InsufficientBalanceException;
import com.cg.mywalletapp.exception.InvalidInputException;

public interface WalletService {

	public void createAccount(Customer customer);

	public Customer showBalance(String mobileno);

	public Customer fundTransfer(String sourceMobileNo, String targetMobileNo, BigDecimal amount);

	public Customer depositAmount(String mobileNo, BigDecimal amount);

	public Customer withdrawAmount(String mobileNo, BigDecimal amount);

	public List<String> printTransactions(String mobileNo);

	public boolean validateCreateMethod(String name, String mobileNo) throws InvalidInputException;

	public boolean validateBalance(BigDecimal balance, String mobileNo) throws InsufficientBalanceException;

	public boolean validateFundTransfer(BigDecimal balance, String mobileNo) throws InsufficientBalanceException;

	public boolean checkMobileAvailable(String monbile)throws InvalidInputException;

}
