package com.cg.mywalletapp.repo;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.cg.mywalletapp.beans.Customer;
import com.cg.mywalletapp.exception.IMyException;
import com.cg.mywalletapp.exception.InsufficientBalanceException;
import com.cg.mywalletapp.exception.InvalidInputException;
import com.cg.mywalletapp.util.DBUtil;

public class WalletRepoImpl implements WalletRepo {


	ArrayList<String> myList = new ArrayList<String>();
	Connection con = null;

	public WalletRepoImpl() {
		try {
			con = DBUtil.getConnect();
		} catch (Exception e) {

			e.printStackTrace();
		}
	}

	
	public void save(Customer customer) {

		try {
			String sql = "INSERT INTO CustomerDetails VALUES(?, ?, ?)";
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setString(1, customer.getName());
			pstmt.setString(2, customer.getMobileNo());
			pstmt.setBigDecimal(3, customer.getWallet());
			pstmt.executeUpdate();
		} catch (Exception e) {

		}

	}

	public Customer findOne(String mobileNo) {
		Customer customer = new Customer();
		try {
			String sql = "SELECT *from CustomerDetails WHERE MOBILE_NUMBER=?";
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setString(1, mobileNo);
			ResultSet res = pstmt.executeQuery();
			if (res.next()) {
				customer.setName(res.getString(1));
				customer.setMobileNo(res.getString(2));
				customer.setWallet(res.getBigDecimal(3));

			}

		} catch (Exception e) {

		}
		return customer;

	}

	public void updateWallet(String mobileNo, BigDecimal amount) {
		try {
			String sql = "UPDATE CustomerDetails set BALANCE=? Where MOBILE_NUMBER=?";
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setBigDecimal(1, amount);
			pstmt.setString(2, mobileNo);
			pstmt.executeUpdate();

		} catch (Exception e) {

		}
	}

	public void addTransactions(String mobileNo, String transaction) {
		try {

			String sql = "INSERT into Print_transaction values(?,?)";
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setString(1, mobileNo);
			pstmt.setString(2, transaction);
			pstmt.executeQuery();

		} catch (Exception e) {
		}

	}

	public List<String> printTransaction(String mobileNo) {
		List<String> myList = new ArrayList<String>();

		try {
			String sql = "Select *from Print_transaction where MOBILENO=?";
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setString(1, mobileNo);
			ResultSet res = pstmt.executeQuery();
			while (res.next()) {
				myList.add(res.getString(2));
			}

		} catch (Exception e) {
			
		}

		return myList;

	}

	public boolean checkMobileAvailable(String mobile) throws InvalidInputException {
		boolean result = false;
		String sql = "Select *from Print_transaction where MOBILENO=?";
		try {
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setString(1, mobile);
			ResultSet res = pstmt.executeQuery();

			if (res.next()) {
				result = true;
			}else {
				throw new InvalidInputException(IMyException.ERROR5);
			}
		} catch (SQLException e) {
			
		}

		return result;
	}


}
