package com.cg.mywalletapp.pl;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import com.cg.mywalletapp.beans.Customer;
import com.cg.mywalletapp.beans.Wallet;
import com.cg.mywalletapp.exception.InsufficientBalanceException;
import com.cg.mywalletapp.exception.InvalidInputException;
import com.cg.mywalletapp.service.WalletService;
import com.cg.mywalletapp.service.WalletServiceImpl;

public class Client {

	public static void main(String[] args) {
		WalletService walletService = new WalletServiceImpl();
		int choice;
		int choice2;

		do {
			System.out.println("1. Create Account");
			System.out.println("2.Login");
			System.out.println("3. Exit");
			System.out.println("Enter Your Choice");
			Scanner scanner = new Scanner(System.in);
			choice = scanner.nextInt();

			Customer customer = new Customer();

			switch (choice) {
			case 1:

				System.out.println("*******Create Account*******");
				System.out.println("Enter Your Name");
				String name = scanner.next();
				System.out.println("Enter Mobile Number");
				String mobileNo = scanner.next();
				System.out.println("Enter Amount");
				BigDecimal amount = scanner.nextBigDecimal();
				try {
					if (walletService.validateCreateMethod(name, mobileNo))
						customer.setName(name);
					customer.setMobileNo(mobileNo);
				} catch (InvalidInputException e) {
					System.out.println(e.getMessage());
				}

				customer.setWallet(amount);
				walletService.createAccount(customer);
				System.out.println("Your Name:         " + customer.getName());
				System.out.println("Your Mobile Number " + customer.getMobileNo());
				System.out.println("your Balance       " + customer.getWallet());
				System.out.println("Account Created");

				break;

			case 2:
				System.out.println("************Login***********");
				System.out.println("Enter Mobile Number");
				String mobileNo1 = scanner.next();

				do {
					System.out.println("1. Show Balance");
					System.out.println("2. Fund Transfer");
					System.out.println("3. Deposit Amount");
					System.out.println("4. Withdraw Amount");
					System.out.println("5. Print Transcript");
					System.out.println("Enter Your Choice");

					choice2 = scanner.nextInt();
					Customer balance = new Customer();
					switch (choice2) {
					case 1:

						Customer cust = walletService.showBalance(mobileNo1);
						System.out.println(cust);
						break;
					case 2:
						System.out.println("**********Fund Transfer************");
						System.out.println("Enter Sender Mobile Number");
						String senderMob = scanner.next();
						System.out.println("Enter Receiver Mobile Number");
						String receiverMob = scanner.next();
						System.out.println("Enter Amount");
						BigDecimal transferAmount = scanner.nextBigDecimal();

						try {
							if (walletService.validateFundTransfer(transferAmount, senderMob)) {

								Customer customer2 = walletService.fundTransfer(senderMob, receiverMob, transferAmount);
								System.out.println(customer2);
							}
						} catch (InsufficientBalanceException e) {
							System.out.println(e.getMessage());
						}

						break;

					case 3:
						System.out.println("**********Deposite*************");

						System.out.println("Enter Deposit Amount ");
						BigDecimal amount1 = scanner.nextBigDecimal();
						Customer depositeCust = walletService.depositAmount(mobileNo1, amount1);
						System.out.println(depositeCust);

						break;

					case 4:
						System.out.println("**********Withdraw*************");

						System.out.println("Enter Withdraw Amount ");
						BigDecimal amount2 = scanner.nextBigDecimal();
						try {
							try {
								if (walletService.validateBalance(amount2, mobileNo1)) {
									Customer withdrawCust = walletService.withdrawAmount(mobileNo1, amount2);
									System.out.println(withdrawCust);
								}
							} catch (InsufficientBalanceException e) {

								System.out.println(e.getMessage());
							}
						} catch (InvalidInputException e) {
							System.out.println(e.getMessage());
						}
						break;
					case 5:
						System.out.println("******Print transcript*******");

						List<String> displayList = walletService.printTransactions(mobileNo1);
						for (String details : displayList) {
							System.out.println(details);
						}
						break;

					case 6:
						System.exit(0);
						break;
					}
				} while (choice2 != 6);

			case 3:
				System.exit(0);
				break;
			}
		} while (choice != 3);
	}

}
